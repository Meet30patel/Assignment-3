// Call the functions once the DOM is ready
$(document).ready(function () {
    fetchData();
  });
  
  // Fetch the data from the JSON file
  function fetchData() {
    // Show a "Loading..." message while the data is being retrieved
    $("#team").html("Loading...");
    // Use jQuery's getJSON() method to retrieve the data
    $.getJSON("../team.json", function (data) {
      // Once the data is retrieved, use it to populate the page
      populatePage(data);
    })
    // If there is an error, display an error message
    .fail(function() {
      $("#team").html("Error: Content could not be retrieved.");
    });
  }
  
  // Populate the page with the data
  function populatePage(data) {
    // Empty the existing contents of the team div
    var teamDiv = $("#team").empty();
    // Loop through the data and add each team member to the page
    $.each(data, function (index, member) {
      var name = "<h2>" + member.name + "</h2>";
      var position = "<h5>" + member.position + "</h5>";
      var bio = "<p>" + member.bio + "</p>";
      var html = name + position + bio;
      teamDiv.append(html);
    });
  }
  